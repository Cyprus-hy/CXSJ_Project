﻿namespace SportSystem
{
    partial class FormUserCenter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UserInfo = new System.Windows.Forms.Button();
            this.CreateTeam = new System.Windows.Forms.Button();
            this.JoinedTeam = new System.Windows.Forms.Button();
            this.BacktoTable = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LogOut = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // UserInfo
            // 
            this.UserInfo.BackColor = System.Drawing.Color.Transparent;
            this.UserInfo.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.UserInfo.Location = new System.Drawing.Point(412, 65);
            this.UserInfo.Margin = new System.Windows.Forms.Padding(4);
            this.UserInfo.Name = "UserInfo";
            this.UserInfo.Size = new System.Drawing.Size(133, 43);
            this.UserInfo.TabIndex = 0;
            this.UserInfo.Text = "个人信息";
            this.UserInfo.UseVisualStyleBackColor = false;
            this.UserInfo.Click += new System.EventHandler(this.UserInfo_Click);
            // 
            // CreateTeam
            // 
            this.CreateTeam.BackColor = System.Drawing.Color.Transparent;
            this.CreateTeam.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CreateTeam.Location = new System.Drawing.Point(412, 191);
            this.CreateTeam.Margin = new System.Windows.Forms.Padding(4);
            this.CreateTeam.Name = "CreateTeam";
            this.CreateTeam.Size = new System.Drawing.Size(133, 47);
            this.CreateTeam.TabIndex = 1;
            this.CreateTeam.Text = "创建队伍";
            this.CreateTeam.UseVisualStyleBackColor = false;
            this.CreateTeam.Click += new System.EventHandler(this.CreateTeam_Click);
            // 
            // JoinedTeam
            // 
            this.JoinedTeam.BackColor = System.Drawing.Color.Transparent;
            this.JoinedTeam.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.JoinedTeam.Location = new System.Drawing.Point(399, 316);
            this.JoinedTeam.Margin = new System.Windows.Forms.Padding(4);
            this.JoinedTeam.Name = "JoinedTeam";
            this.JoinedTeam.Size = new System.Drawing.Size(157, 44);
            this.JoinedTeam.TabIndex = 2;
            this.JoinedTeam.Text = "已参加比赛";
            this.JoinedTeam.UseVisualStyleBackColor = false;
            this.JoinedTeam.Click += new System.EventHandler(this.JoinedTeam_Click);
            // 
            // BacktoTable
            // 
            this.BacktoTable.BackColor = System.Drawing.Color.Transparent;
            this.BacktoTable.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BacktoTable.Location = new System.Drawing.Point(13, 13);
            this.BacktoTable.Margin = new System.Windows.Forms.Padding(4);
            this.BacktoTable.Name = "BacktoTable";
            this.BacktoTable.Size = new System.Drawing.Size(88, 38);
            this.BacktoTable.TabIndex = 3;
            this.BacktoTable.Text = "返回";
            this.BacktoTable.UseVisualStyleBackColor = false;
            this.BacktoTable.Click += new System.EventHandler(this.BacktoTable_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportSystem.Properties.Resources.EB4FA52FEF11A44ED8D516B1C60A7768;
            this.pictureBox1.Location = new System.Drawing.Point(1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(951, 562);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // LogOut
            // 
            this.LogOut.BackColor = System.Drawing.Color.Transparent;
            this.LogOut.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LogOut.Location = new System.Drawing.Point(412, 440);
            this.LogOut.Name = "LogOut";
            this.LogOut.Size = new System.Drawing.Size(133, 47);
            this.LogOut.TabIndex = 5;
            this.LogOut.Text = "退出登录";
            this.LogOut.UseVisualStyleBackColor = false;
            this.LogOut.Click += new System.EventHandler(this.LogOut_Click);
            // 
            // FormUserCenter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 553);
            this.Controls.Add(this.LogOut);
            this.Controls.Add(this.BacktoTable);
            this.Controls.Add(this.JoinedTeam);
            this.Controls.Add(this.CreateTeam);
            this.Controls.Add(this.UserInfo);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormUserCenter";
            this.Text = "用户中心";
            this.Load += new System.EventHandler(this.FormUserCenter_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button UserInfo;
        private System.Windows.Forms.Button CreateTeam;
        private System.Windows.Forms.Button JoinedTeam;
        private System.Windows.Forms.Button BacktoTable;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button LogOut;
    }
}