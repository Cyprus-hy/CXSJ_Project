﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormSearchAd : Form
    {
        public FormSearchAd()
        {
            InitializeComponent();
        }

        public string HttpGet(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url + (postDataStr == "" ? "" : "?") + postDataStr);
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            return retString;
        }

        private void search_Click(object sender, EventArgs e)
        {
            ListNotices.Items.Clear();//清除表格

            string URL = "http://localhost/cxsj_final_project-master/Home/Billboard/getInfoByID/" + Id.Text;
            string content = HttpGet(URL, "");
            ad resultobj = JsonConvert.DeserializeObject<ad>(content);

            ListViewItem lv = new ListViewItem();
            lv.Text = Id.Text;
            lv.SubItems.Add(resultobj.ad_name);
            lv.SubItems.Add(resultobj.ad_content);
            lv.SubItems.Add(resultobj.ad_data_time);
            ListNotices.Items.Add(lv);
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void FormSearchAd_Load(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(0, 0);
            Back.Parent = pictureBox1;
            label1.Parent = pictureBox1;
            search.Parent = pictureBox1;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
