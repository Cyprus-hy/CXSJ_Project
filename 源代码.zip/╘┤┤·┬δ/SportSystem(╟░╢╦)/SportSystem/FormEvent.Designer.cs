﻿namespace SportSystem
{
    partial class FormEvent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EventInfo = new System.Windows.Forms.Button();
            this.DeleteEvent = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.CreateEvent = new System.Windows.Forms.Button();
            this.EventState = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // EventInfo
            // 
            this.EventInfo.BackColor = System.Drawing.Color.Transparent;
            this.EventInfo.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EventInfo.Location = new System.Drawing.Point(384, 72);
            this.EventInfo.Name = "EventInfo";
            this.EventInfo.Size = new System.Drawing.Size(135, 41);
            this.EventInfo.TabIndex = 0;
            this.EventInfo.Text = "活动信息";
            this.EventInfo.UseVisualStyleBackColor = false;
            this.EventInfo.Click += new System.EventHandler(this.EventInfo_Click);
            // 
            // DeleteEvent
            // 
            this.DeleteEvent.BackColor = System.Drawing.Color.Transparent;
            this.DeleteEvent.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DeleteEvent.Location = new System.Drawing.Point(384, 318);
            this.DeleteEvent.Name = "DeleteEvent";
            this.DeleteEvent.Size = new System.Drawing.Size(135, 38);
            this.DeleteEvent.TabIndex = 2;
            this.DeleteEvent.Text = "删除活动";
            this.DeleteEvent.UseVisualStyleBackColor = false;
            this.DeleteEvent.Click += new System.EventHandler(this.DeleteEvent_Click);
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.Transparent;
            this.Back.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Back.Location = new System.Drawing.Point(12, 12);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(75, 33);
            this.Back.TabIndex = 4;
            this.Back.Text = "返回";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // CreateEvent
            // 
            this.CreateEvent.BackColor = System.Drawing.Color.Transparent;
            this.CreateEvent.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CreateEvent.Location = new System.Drawing.Point(384, 197);
            this.CreateEvent.Name = "CreateEvent";
            this.CreateEvent.Size = new System.Drawing.Size(135, 38);
            this.CreateEvent.TabIndex = 5;
            this.CreateEvent.Text = "创建活动";
            this.CreateEvent.UseVisualStyleBackColor = false;
            this.CreateEvent.Click += new System.EventHandler(this.CreateEvent_Click);
            // 
            // EventState
            // 
            this.EventState.BackColor = System.Drawing.Color.Transparent;
            this.EventState.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EventState.Location = new System.Drawing.Point(360, 445);
            this.EventState.Name = "EventState";
            this.EventState.Size = new System.Drawing.Size(176, 40);
            this.EventState.TabIndex = 9;
            this.EventState.Text = "查看报名状态";
            this.EventState.UseVisualStyleBackColor = false;
            this.EventState.Click += new System.EventHandler(this.EventState_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportSystem.Properties.Resources.EB4FA52FEF11A44ED8D516B1C60A7768;
            this.pictureBox1.Location = new System.Drawing.Point(0, -5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(953, 564);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormEvent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 553);
            this.Controls.Add(this.EventState);
            this.Controls.Add(this.CreateEvent);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.DeleteEvent);
            this.Controls.Add(this.EventInfo);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormEvent";
            this.Text = "体育活动";
            this.Load += new System.EventHandler(this.FormEvent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button EventInfo;
        private System.Windows.Forms.Button DeleteEvent;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button CreateEvent;
        private System.Windows.Forms.Button EventState;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}