﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class LoginUser
    {
        public int user_id;
        public string password;


        public LoginUser(int UserID, string Password)
        {
            user_id = UserID;
            password = Password;
        }
    }
}
