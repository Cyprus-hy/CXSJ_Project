﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportSystem
{
    public partial class FormNotice : Form
    {
        public FormNotice()
        {
            InitializeComponent();
        }

        private void FormNotice_Load(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(0, 0);
            PostAd.Parent = pictureBox1;
            Back.Parent = pictureBox1;
            SearchAd.Parent = pictureBox1;
        }

        private void SearchAd_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormSearchAd().ShowDialog(this);
        }

        private void PostAd_Click(object sender, EventArgs e)
        {
            if(Common.admin==1)
            {
                this.Hide();
                new FormPostAd().ShowDialog(this);
            }
            else
            {
                MessageBox.Show("对不起，仅有管理员才有此权限！");
            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
