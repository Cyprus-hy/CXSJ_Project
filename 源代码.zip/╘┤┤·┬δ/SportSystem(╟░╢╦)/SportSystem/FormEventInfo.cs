﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormEventInfo : Form
    {
        public FormEventInfo()
        {
            InitializeComponent();
        }

        private string HttpPost(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = Encoding.UTF8.GetByteCount(postDataStr);
            Stream myRequestStream = request.GetRequestStream();
            StreamWriter myStreamWriter = new StreamWriter(myRequestStream, Encoding.GetEncoding("gb2312"));
            myStreamWriter.Write(postDataStr);
            myStreamWriter.Close();

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();

            return retString;
        }

        public string HttpGet(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url + (postDataStr == "" ? "" : "?") + postDataStr);
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            return retString;
        }

        private void Search_Click(object sender, EventArgs e)
        {
            ListEvent.Items.Clear();//清除表格

            string URL = "http://localhost/cxsj_final_project-master/Home/Event/getInfoByID/" + EventID.Text;
            string content = HttpGet(URL, "");
            Event resultobj = JsonConvert.DeserializeObject<Event>(content);

            ListViewItem lv = new ListViewItem();
            lv.Text = EventID.Text;
            lv.SubItems.Add(resultobj.event_name);
            lv.SubItems.Add(Convert.ToString(resultobj.max_team_member));
            lv.SubItems.Add(Convert.ToString(resultobj.min_team_member));
            lv.SubItems.Add(Convert.ToString(resultobj.team_limit));
            lv.SubItems.Add(Convert.ToString(resultobj.year));
            ListEvent.Items.Add(lv);
        }

        private void Join_Click(object sender, EventArgs e)
        {
            Registration newobj = new Registration(Convert.ToInt32(id_team.Text), Convert.ToInt32(EventID.Text));
            string PostURL = "http://localhost/cxsj_final_project-master/Home/Registration/postNewRegistration";
            string jsonContent = JsonConvert.SerializeObject(newobj);
            string Param = "Content=" + jsonContent;
            string result = HttpPost(PostURL, Param);

            MessageBox.Show("恭喜您报名成功！");
            id_team.Text = "";
        }

        private void FormEventInfo_Load(object sender, EventArgs e)
        {
            ListEvent.Items.Clear();//清除表格

            pictureBox1.Location = new Point(0, 0);
            Back.Parent = pictureBox1;
            label1.Parent = pictureBox1;
            TeamID.Parent = pictureBox1;
            Search.Parent = pictureBox1;
            Join.Parent = pictureBox1;

            string URL = "http://localhost/cxsj_final_project-master/Home/Event/getAllID";
            string result = HttpGet(URL, "");
            List<Event> resultobj = JsonConvert.DeserializeObject<List<Event>>(result);
            int count = resultobj.Count();

            for (int i = 0; i < count; i++)
            {
                ListViewItem lv = new ListViewItem();
                lv.Text = Convert.ToString(resultobj[i].event_id);
                lv.SubItems.Add(resultobj[i].event_name);
                lv.SubItems.Add(Convert.ToString(resultobj[i].max_team_member));
                lv.SubItems.Add(Convert.ToString(resultobj[i].min_team_member));
                lv.SubItems.Add(Convert.ToString(resultobj[i].team_limit));
                lv.SubItems.Add(Convert.ToString(resultobj[i].year));
                ListEvent.Items.Add(lv);
            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void id_team_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
