﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class IsLogin
    {
        public bool is_login;
        public bool is_admin;

        public IsLogin(bool login, bool admin)
        {
            is_login = login;
            is_admin = admin;
        }
    }
}
