﻿namespace SportSystem
{
    partial class FormReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labName = new System.Windows.Forms.Label();
            this.inputUser_id = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.inputName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.inputPhone = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.inputGender = new System.Windows.Forms.TextBox();
            this.labPwd = new System.Windows.Forms.Label();
            this.inputEmail = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.inputPwd = new System.Windows.Forms.TextBox();
            this.labRealName = new System.Windows.Forms.Label();
            this.inputDep_id = new System.Windows.Forms.TextBox();
            this.btnReg = new System.Windows.Forms.Button();
            this.btnToLogin = new System.Windows.Forms.Button();
            this.chePwd = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labName
            // 
            this.labName.AutoSize = true;
            this.labName.BackColor = System.Drawing.Color.Transparent;
            this.labName.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labName.Location = new System.Drawing.Point(219, 24);
            this.labName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labName.Name = "labName";
            this.labName.Size = new System.Drawing.Size(82, 24);
            this.labName.TabIndex = 8;
            this.labName.Text = "学号：";
            // 
            // inputUser_id
            // 
            this.inputUser_id.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.inputUser_id.Location = new System.Drawing.Point(395, 20);
            this.inputUser_id.Margin = new System.Windows.Forms.Padding(4);
            this.inputUser_id.Name = "inputUser_id";
            this.inputUser_id.Size = new System.Drawing.Size(280, 34);
            this.inputUser_id.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(219, 75);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 24);
            this.label4.TabIndex = 23;
            this.label4.Text = "姓名：";
            // 
            // inputName
            // 
            this.inputName.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.inputName.Location = new System.Drawing.Point(395, 72);
            this.inputName.Margin = new System.Windows.Forms.Padding(4);
            this.inputName.Name = "inputName";
            this.inputName.Size = new System.Drawing.Size(280, 34);
            this.inputName.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(219, 132);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 24);
            this.label1.TabIndex = 25;
            this.label1.Text = "电话号码：";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // inputPhone
            // 
            this.inputPhone.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.inputPhone.Location = new System.Drawing.Point(395, 129);
            this.inputPhone.Margin = new System.Windows.Forms.Padding(4);
            this.inputPhone.Name = "inputPhone";
            this.inputPhone.Size = new System.Drawing.Size(280, 34);
            this.inputPhone.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(219, 199);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 24);
            this.label2.TabIndex = 27;
            this.label2.Text = "性别：";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // inputGender
            // 
            this.inputGender.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.inputGender.Location = new System.Drawing.Point(395, 196);
            this.inputGender.Margin = new System.Windows.Forms.Padding(4);
            this.inputGender.Name = "inputGender";
            this.inputGender.Size = new System.Drawing.Size(280, 34);
            this.inputGender.TabIndex = 28;
            // 
            // labPwd
            // 
            this.labPwd.AutoSize = true;
            this.labPwd.BackColor = System.Drawing.Color.Transparent;
            this.labPwd.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labPwd.Location = new System.Drawing.Point(219, 265);
            this.labPwd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labPwd.Name = "labPwd";
            this.labPwd.Size = new System.Drawing.Size(82, 24);
            this.labPwd.TabIndex = 29;
            this.labPwd.Text = "邮箱：";
            this.labPwd.Click += new System.EventHandler(this.labPwd_Click);
            // 
            // inputEmail
            // 
            this.inputEmail.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.inputEmail.Location = new System.Drawing.Point(395, 262);
            this.inputEmail.Margin = new System.Windows.Forms.Padding(4);
            this.inputEmail.Name = "inputEmail";
            this.inputEmail.Size = new System.Drawing.Size(280, 34);
            this.inputEmail.TabIndex = 30;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(219, 403);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 24);
            this.label3.TabIndex = 31;
            this.label3.Text = "密码：";
            // 
            // inputPwd
            // 
            this.inputPwd.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.inputPwd.Location = new System.Drawing.Point(395, 400);
            this.inputPwd.Margin = new System.Windows.Forms.Padding(4);
            this.inputPwd.Name = "inputPwd";
            this.inputPwd.PasswordChar = '*';
            this.inputPwd.Size = new System.Drawing.Size(280, 34);
            this.inputPwd.TabIndex = 32;
            // 
            // labRealName
            // 
            this.labRealName.AutoSize = true;
            this.labRealName.BackColor = System.Drawing.Color.Transparent;
            this.labRealName.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labRealName.Location = new System.Drawing.Point(219, 331);
            this.labRealName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labRealName.Name = "labRealName";
            this.labRealName.Size = new System.Drawing.Size(106, 24);
            this.labRealName.TabIndex = 33;
            this.labRealName.Text = "学院ID：";
            // 
            // inputDep_id
            // 
            this.inputDep_id.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.inputDep_id.Location = new System.Drawing.Point(395, 328);
            this.inputDep_id.Margin = new System.Windows.Forms.Padding(4);
            this.inputDep_id.Name = "inputDep_id";
            this.inputDep_id.Size = new System.Drawing.Size(280, 34);
            this.inputDep_id.TabIndex = 34;
            // 
            // btnReg
            // 
            this.btnReg.BackColor = System.Drawing.Color.Transparent;
            this.btnReg.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnReg.Location = new System.Drawing.Point(252, 501);
            this.btnReg.Margin = new System.Windows.Forms.Padding(4);
            this.btnReg.Name = "btnReg";
            this.btnReg.Size = new System.Drawing.Size(73, 39);
            this.btnReg.TabIndex = 35;
            this.btnReg.Text = "注册";
            this.btnReg.UseVisualStyleBackColor = false;
            this.btnReg.Click += new System.EventHandler(this.btnReg_Click);
            // 
            // btnToLogin
            // 
            this.btnToLogin.BackColor = System.Drawing.Color.Transparent;
            this.btnToLogin.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnToLogin.Location = new System.Drawing.Point(528, 501);
            this.btnToLogin.Margin = new System.Windows.Forms.Padding(4);
            this.btnToLogin.Name = "btnToLogin";
            this.btnToLogin.Size = new System.Drawing.Size(147, 39);
            this.btnToLogin.TabIndex = 36;
            this.btnToLogin.Text = "返回登录页面";
            this.btnToLogin.UseVisualStyleBackColor = false;
            this.btnToLogin.Click += new System.EventHandler(this.btnToLogin_Click);
            // 
            // chePwd
            // 
            this.chePwd.AutoSize = true;
            this.chePwd.BackColor = System.Drawing.Color.Transparent;
            this.chePwd.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.chePwd.Location = new System.Drawing.Point(547, 453);
            this.chePwd.Margin = new System.Windows.Forms.Padding(4);
            this.chePwd.Name = "chePwd";
            this.chePwd.Size = new System.Drawing.Size(128, 28);
            this.chePwd.TabIndex = 37;
            this.chePwd.Text = "显示密码";
            this.chePwd.UseVisualStyleBackColor = false;
            this.chePwd.CheckedChanged += new System.EventHandler(this.chePwd_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportSystem.Properties.Resources.EB4FA52FEF11A44ED8D516B1C60A7768;
            this.pictureBox1.Location = new System.Drawing.Point(0, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(885, 559);
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 553);
            this.Controls.Add(this.chePwd);
            this.Controls.Add(this.btnToLogin);
            this.Controls.Add(this.btnReg);
            this.Controls.Add(this.inputDep_id);
            this.Controls.Add(this.labRealName);
            this.Controls.Add(this.inputPwd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.inputEmail);
            this.Controls.Add(this.labPwd);
            this.Controls.Add(this.inputGender);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.inputPhone);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.inputName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.inputUser_id);
            this.Controls.Add(this.labName);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormReg";
            this.Text = "注册界面";
            this.Load += new System.EventHandler(this.FormReg_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labName;
        private System.Windows.Forms.TextBox inputUser_id;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox inputName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox inputPhone;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox inputGender;
        private System.Windows.Forms.Label labPwd;
        private System.Windows.Forms.TextBox inputEmail;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox inputPwd;
        private System.Windows.Forms.Label labRealName;
        private System.Windows.Forms.TextBox inputDep_id;
        private System.Windows.Forms.Button btnReg;
        private System.Windows.Forms.Button btnToLogin;
        private System.Windows.Forms.CheckBox chePwd;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}