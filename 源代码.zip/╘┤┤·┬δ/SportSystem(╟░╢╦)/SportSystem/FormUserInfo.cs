﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormUserInfo : Form
    {
        public FormUserInfo()
        {
            InitializeComponent();
        }

        public string HttpGet(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url + (postDataStr == "" ? "" : "?") + postDataStr);
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            return retString;
        }

        private void FormUserInfo_Load(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(0, 0);
            Back.Parent = pictureBox1;
            label1.Parent = pictureBox1;
            label2.Parent = pictureBox1;
            label3.Parent = pictureBox1;
            label4.Parent = pictureBox1;
            label5.Parent = pictureBox1;
            label6.Parent = pictureBox1;
            label7.Parent = pictureBox1;

            // 获取个人信息
            string URL = "http://localhost/cxsj_final_project-master/Home/User/getInfoByUserID/" + Common.Login_ID;
            string content = HttpGet(URL, "");
            // 将得到的信息进行划分，注意这里的返回值
            //string result = content.Substring(0, 6) + content.Substring(content.Length - 1);
            //List<String> res = JsonConvert.DeserializeObject<List<String>>(content);

            User resultobj = JsonConvert.DeserializeObject<User>(content);
            userID.Text = Convert.ToString(resultobj.user_id);
            userName.Text = resultobj.name;
            userGender.Text = Convert.ToString(resultobj.gender);
            userPhone.Text = resultobj.phone;
            userEmail.Text = resultobj.email;
            password.Text = resultobj.password;

            string dep_id = Convert.ToString(resultobj.department_id);
            // 获得院系名称
            string GetUrl = "http://localhost/cxsj_final_project-master/Home/User/getInfoByDepartID/" + dep_id;
            string tem = HttpGet(GetUrl, "");
            string dep_name = JsonConvert.DeserializeObject <string> (tem);
            userDep.Text = dep_name;
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }
    }
}
