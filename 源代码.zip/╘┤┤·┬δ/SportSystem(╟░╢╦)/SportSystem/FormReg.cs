﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormReg : Form
    {
        public FormReg()
        {
            InitializeComponent();
        }

        private string HttpPost(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = Encoding.UTF8.GetByteCount(postDataStr);
            Stream myRequestStream = request.GetRequestStream();
            StreamWriter myStreamWriter = new StreamWriter(myRequestStream, Encoding.GetEncoding("gb2312"));
            myStreamWriter.Write(postDataStr);
            myStreamWriter.Close();

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();

            return retString;
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            if (ToolUtil.AnyEmpty(inputUser_id.Text, inputDep_id.Text, inputPhone.Text, inputGender.Text,
                inputPwd.Text, inputName.Text, inputEmail.Text))
            {
                MessageBox.Show("请填写您的所有信息！");
                return;
            }

            int userID = Convert.ToInt32(inputUser_id.Text);
            int depID = Convert.ToInt32(inputDep_id.Text);
            string userPhone = inputPhone.Text;
            int userGender = Convert.ToInt32(inputGender.Text);
            string userEmail = inputEmail.Text;
            string userName = inputName.Text;
            string password = inputPwd.Text;

            

            User newobj = new User(userID, userName, userPhone, userGender, userEmail, depID, password);
            string PostURL = "http://localhost/cxsj_final_project-master/Home/User/postNewUser";
            string jsonContent = JsonConvert.SerializeObject(newobj);
            string Param = "Content=" + jsonContent;
            string result = HttpPost(PostURL, Param);
            IsReg resultobj = JsonConvert.DeserializeObject<IsReg>(result);

            if (resultobj.is_exist)
            {
                MessageBox.Show("对不起，该账号已存在！");
            }
            else
            {
                MessageBox.Show("恭喜您注册成功！");
                inputUser_id.Text = "";
                inputDep_id.Text = "";
                inputPhone.Text = "";
                inputGender.Text = "";
                inputPwd.Text = "";
                inputName.Text = "";
                inputEmail.Text = "";
            }
        }

        private void btnToLogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void chePwd_CheckedChanged(object sender, EventArgs e)
        {
            if (chePwd.Checked == true)
            {
                inputPwd.PasswordChar = new char();
            }
            else
            {
                inputPwd.PasswordChar = '*';
            }
        }

        private void RegClose(object sender, FormClosedEventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void FormReg_Load(object sender, EventArgs e)
        {
            inputUser_id.Text = "";
            inputDep_id.Text = "";
            inputPhone.Text = "";
            inputGender.Text = "";
            inputPwd.Text = "";
            inputName.Text = "";
            inputEmail.Text = "";
            inputUser_id.Focus();//自动得到焦点

            pictureBox1.Location = new Point(0, 0);
            label1.Parent = pictureBox1;
            label2.Parent = pictureBox1;
            label3.Parent = pictureBox1;
            label4.Parent = pictureBox1;
            labName.Parent = pictureBox1;
            labPwd.Parent = pictureBox1;
            labRealName.Parent = pictureBox1;
            chePwd.Parent = pictureBox1;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void labPwd_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
