﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class Common
    {
        private static int Login_id = 0;//登陆者的学号
        private static int is_admin = 0;//是否为管理者
        
        public static int Login_ID
        {
            get { return Login_id; }
            set { Login_id = value; }
        }

        public static int admin
        {
            get { return is_admin; }
            set { is_admin = value; }
        }
    }
}
