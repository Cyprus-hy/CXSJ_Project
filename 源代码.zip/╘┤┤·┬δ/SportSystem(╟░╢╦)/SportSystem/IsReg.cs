﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class IsReg
    {
        public bool is_exist;

        public IsReg(bool exist)
        {
            is_exist = exist;
        }
    }
}
