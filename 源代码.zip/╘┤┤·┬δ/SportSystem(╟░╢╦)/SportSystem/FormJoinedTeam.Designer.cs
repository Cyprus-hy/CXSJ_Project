﻿namespace SportSystem
{
    partial class FormJoinedTeam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Back = new System.Windows.Forms.Button();
            this.ListJoinedTeam = new System.Windows.Forms.ListView();
            this.team_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.team_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.eventid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.event_time = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.reg_time = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.Transparent;
            this.Back.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Back.Location = new System.Drawing.Point(12, 12);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(85, 33);
            this.Back.TabIndex = 1;
            this.Back.Text = "返回";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // ListJoinedTeam
            // 
            this.ListJoinedTeam.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.team_id,
            this.team_name,
            this.eventid,
            this.event_time,
            this.reg_time});
            this.ListJoinedTeam.Location = new System.Drawing.Point(25, 90);
            this.ListJoinedTeam.Margin = new System.Windows.Forms.Padding(4);
            this.ListJoinedTeam.Name = "ListJoinedTeam";
            this.ListJoinedTeam.Size = new System.Drawing.Size(904, 402);
            this.ListJoinedTeam.TabIndex = 8;
            this.ListJoinedTeam.UseCompatibleStateImageBehavior = false;
            this.ListJoinedTeam.View = System.Windows.Forms.View.Details;
            // 
            // team_id
            // 
            this.team_id.Text = "队伍ID";
            this.team_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.team_id.Width = 150;
            // 
            // team_name
            // 
            this.team_name.Text = "队伍名称";
            this.team_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.team_name.Width = 150;
            // 
            // eventid
            // 
            this.eventid.Text = "活动ID";
            this.eventid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.eventid.Width = 200;
            // 
            // event_time
            // 
            this.event_time.Text = "活动名称";
            this.event_time.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.event_time.Width = 200;
            // 
            // reg_time
            // 
            this.reg_time.Text = "报名时间";
            this.reg_time.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.reg_time.Width = 200;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportSystem.Properties.Resources.EB4FA52FEF11A44ED8D516B1C60A7768;
            this.pictureBox1.Location = new System.Drawing.Point(-4, -6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(946, 559);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormJoinedTeam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 553);
            this.Controls.Add(this.ListJoinedTeam);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormJoinedTeam";
            this.Text = "已参加比赛";
            this.Load += new System.EventHandler(this.FormJoinedTeam_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.ListView ListJoinedTeam;
        private System.Windows.Forms.ColumnHeader team_id;
        private System.Windows.Forms.ColumnHeader team_name;
        private System.Windows.Forms.ColumnHeader eventid;
        private System.Windows.Forms.ColumnHeader event_time;
        private System.Windows.Forms.ColumnHeader reg_time;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}