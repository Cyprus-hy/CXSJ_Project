﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormTable : Form
    {
        public FormTable()
        {
            InitializeComponent();
        }

        public string HttpGet(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url + (postDataStr == "" ? "" : "?") + postDataStr);
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            return retString;
        }

        private void FormTable_Load(object sender, EventArgs e)
        {
            
            ListNotices.Items.Clear();//清除表格
            pictureBox1.Location = new Point(0, 0);
            FirstPage.Parent = pictureBox1;
            PublicNotice.Parent = pictureBox1;
            SportsEvent.Parent = pictureBox1;
            UserCenter.Parent = pictureBox1;
            label1.Parent = pictureBox1;

            string URL = "http://localhost/cxsj_final_project-master/Home/Billboard/getAllInfo";
            string result = HttpGet(URL, "");
            List<ad> resultobj = JsonConvert.DeserializeObject<List<ad>>(result);
            int count = resultobj.Count();

            for (int i = 0; i < count; i++)
            {
                ListViewItem lv = new ListViewItem();
                lv.Text = Convert.ToString(resultobj[i].ad_id);//第一列数据
                lv.SubItems.Add(resultobj[i].ad_name);
                lv.SubItems.Add(resultobj[i].ad_content);
                lv.SubItems.Add(resultobj[i].ad_data_time);
                ListNotices.Items.Add(lv);
            }
        }

        private void FirstPage_Click(object sender, EventArgs e)
        {
            ListNotices.Items.Clear();//清除表格
            string URL = "http://localhost/cxsj_final_project-master/Home/Billboard/getAllInfo";
            string result = HttpGet(URL, "");
            List<ad> resultobj = JsonConvert.DeserializeObject<List<ad>>(result);
            int count = resultobj.Count();

            for (int i = 0; i < count; i++)
            {
                ListViewItem lv = new ListViewItem();
                lv.Text = Convert.ToString(resultobj[i].ad_id);//第一列数据
                lv.SubItems.Add(resultobj[i].ad_name);
                lv.SubItems.Add(resultobj[i].ad_content);
                lv.SubItems.Add(resultobj[i].ad_data_time);
                ListNotices.Items.Add(lv);
            }
        }

        private void PublicNotice_Click(object sender, EventArgs e)
        {
            if (Common.admin == 1)
            {
                this.Hide();
                new FormPostAd().ShowDialog(this);
            }
            else
            {
                MessageBox.Show("对不起，仅有管理员才有此权限！");
            }
        }

        private void SportsEvent_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormEvent().ShowDialog(this);
        }

        private void UserCenter_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormUserCenter().ShowDialog(this);
        }

        private void ListNotices_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void search_Click(object sender, EventArgs e)
        {
            ListNotices.Items.Clear();//清除表格

            string URL = "http://localhost/cxsj_final_project-master/Home/Billboard/getInfoByID/" + Id.Text;
            string content = HttpGet(URL, "");
            ad resultobj = JsonConvert.DeserializeObject<ad>(content);

            ListViewItem lv = new ListViewItem();
            lv.Text = Id.Text;
            lv.SubItems.Add(resultobj.ad_name);
            lv.SubItems.Add(resultobj.ad_content);
            lv.SubItems.Add(resultobj.ad_data_time);
            ListNotices.Items.Add(lv);
        }
    }
}
