﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class JoinedTeam
    {
        public int team_id;
        public string team_name;
        public int event_id;
        public string event_name;
        public string reg_time;

        public JoinedTeam (int t_id,string t_name,int e_id,string e_name,string r_time)
        {
            team_id = t_id;
            team_name = t_name;
            event_id = e_id;
            event_name = e_name;
            reg_time = r_time;
        }
    }
}
