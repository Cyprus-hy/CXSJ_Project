﻿namespace SportSystem
{
    partial class FormCreateEvent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Back = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.max_mem = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.min_mem = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Elimit = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Eyear = new System.Windows.Forms.TextBox();
            this.Submit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.Transparent;
            this.Back.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Back.Location = new System.Drawing.Point(12, 12);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(85, 32);
            this.Back.TabIndex = 1;
            this.Back.Text = "返回";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(301, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "活动名称：";
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.name.Location = new System.Drawing.Point(484, 84);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(236, 34);
            this.name.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(301, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 24);
            this.label2.TabIndex = 8;
            this.label2.Text = "最大队员人数：";
            // 
            // max_mem
            // 
            this.max_mem.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.max_mem.Location = new System.Drawing.Point(484, 158);
            this.max_mem.Name = "max_mem";
            this.max_mem.Size = new System.Drawing.Size(236, 34);
            this.max_mem.TabIndex = 9;
            this.max_mem.TextChanged += new System.EventHandler(this.max_mem_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(301, 238);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 24);
            this.label3.TabIndex = 10;
            this.label3.Text = "最小队员人数：";
            // 
            // min_mem
            // 
            this.min_mem.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.min_mem.Location = new System.Drawing.Point(485, 235);
            this.min_mem.Name = "min_mem";
            this.min_mem.Size = new System.Drawing.Size(236, 34);
            this.min_mem.TabIndex = 11;
            this.min_mem.TextChanged += new System.EventHandler(this.min_mem_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(301, 312);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(178, 24);
            this.label4.TabIndex = 12;
            this.label4.Text = "队伍数量限制：";
            // 
            // Elimit
            // 
            this.Elimit.Location = new System.Drawing.Point(484, 312);
            this.Elimit.Name = "Elimit";
            this.Elimit.Size = new System.Drawing.Size(236, 30);
            this.Elimit.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(301, 387);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 24);
            this.label5.TabIndex = 14;
            this.label5.Text = "比赛年份：";
            // 
            // Eyear
            // 
            this.Eyear.Location = new System.Drawing.Point(484, 387);
            this.Eyear.Name = "Eyear";
            this.Eyear.Size = new System.Drawing.Size(236, 30);
            this.Eyear.TabIndex = 15;
            // 
            // Submit
            // 
            this.Submit.BackColor = System.Drawing.Color.Transparent;
            this.Submit.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Submit.Location = new System.Drawing.Point(425, 456);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(92, 34);
            this.Submit.TabIndex = 16;
            this.Submit.Text = "创建";
            this.Submit.UseVisualStyleBackColor = false;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportSystem.Properties.Resources.EB4FA52FEF11A44ED8D516B1C60A7768;
            this.pictureBox1.Location = new System.Drawing.Point(-4, -4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(961, 559);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormCreateEvent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 553);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.Eyear);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Elimit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.min_mem);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.max_mem);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.name);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormCreateEvent";
            this.Text = "创建活动";
            this.Load += new System.EventHandler(this.FormPostEvent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox max_mem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox min_mem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Elimit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Eyear;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}