﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormCreateTeam : Form
    {
        List<int> Team_members = new List<int>();

        public FormCreateTeam()
        {
            InitializeComponent();
        }

        private string HttpPost(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = Encoding.UTF8.GetByteCount(postDataStr);
            Stream myRequestStream = request.GetRequestStream();
            StreamWriter myStreamWriter = new StreamWriter(myRequestStream, Encoding.GetEncoding("gb2312"));
            myStreamWriter.Write(postDataStr);
            myStreamWriter.Close();

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();

            return retString;
        }

        private void Submit_Click(object sender, EventArgs e)
        {
            string Team_name = TeamName.Text;

            if(Convert.ToInt32(TeamNumber.Text)!= Team_members.Count())
            {
                MessageBox.Show("对不起，您添加的队伍人数过多或过少！");
            }

            else
            {
                Team newobj = new Team(Team_name, Team_members);
                string PostURL = "http://localhost/cxsj_final_project-master/Home/Team/postNewTeam";
                string jsonContent = JsonConvert.SerializeObject(newobj);
                string Param = "Content=" + jsonContent;
                int result = JsonConvert.DeserializeObject<int>(HttpPost(PostURL, Param));



                if (result > 0)
                {
                    MessageBox.Show("创建成功！您的队伍ID为：" + result);
                    TeamName.Text = "";
                    TeamNumber.Text = "";
                    TeamMember.Text = "";
                }
                else
                {
                    MessageBox.Show("对不起，创建失败！");
                }
            }
            
        }

        private void FormCreateTeam_Load(object sender, EventArgs e)
        {
            TeamName.Text = "";
            TeamNumber.Text = "";
            TeamMember.Text = "";
            TeamName.Focus();

            pictureBox1.Location = new Point(0, 0);
            label1.Parent = pictureBox1;
            label2.Parent = pictureBox1;
            label3.Parent = pictureBox1;
            Back.Parent = pictureBox1;
            Submit.Parent = pictureBox1;
            Add.Parent = pictureBox1;
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            //每次添加一位成员的学号
            Team_members.Add(Convert.ToInt32(TeamMember.Text));
            TeamMember.Text = "";
        }

        private void TeamNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
