﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class Reg
    {
        public int team_id;
        public int event_id;
        public int user_id;
        public string user_name;

        public Reg(int t_id,int e_id,int u_id,string u_name)
        {
            team_id = t_id;
            event_id = e_id;
            user_id = u_id;
            user_name = u_name;
        }
    }
}
