﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class Registration
    {
        public int team_id;
        public int event_id;

        public Registration(int team, int eve)
        {
            team_id = team;
            event_id = eve;
        }
    }
}
