﻿namespace SportSystem
{
    partial class FormTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UserCenter = new System.Windows.Forms.Button();
            this.SportsEvent = new System.Windows.Forms.Button();
            this.PublicNotice = new System.Windows.Forms.Button();
            this.ListNotices = new System.Windows.Forms.ListView();
            this.ad_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ad_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ad_content = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ad_data_time = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.FirstPage = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Id = new System.Windows.Forms.TextBox();
            this.search = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // UserCenter
            // 
            this.UserCenter.BackColor = System.Drawing.Color.Transparent;
            this.UserCenter.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.UserCenter.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.UserCenter.Location = new System.Drawing.Point(781, 12);
            this.UserCenter.Margin = new System.Windows.Forms.Padding(4);
            this.UserCenter.Name = "UserCenter";
            this.UserCenter.Size = new System.Drawing.Size(114, 45);
            this.UserCenter.TabIndex = 0;
            this.UserCenter.Text = "用户中心";
            this.UserCenter.UseVisualStyleBackColor = false;
            this.UserCenter.Click += new System.EventHandler(this.UserCenter_Click);
            // 
            // SportsEvent
            // 
            this.SportsEvent.BackColor = System.Drawing.Color.Transparent;
            this.SportsEvent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SportsEvent.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SportsEvent.Location = new System.Drawing.Point(523, 13);
            this.SportsEvent.Margin = new System.Windows.Forms.Padding(4);
            this.SportsEvent.Name = "SportsEvent";
            this.SportsEvent.Size = new System.Drawing.Size(115, 43);
            this.SportsEvent.TabIndex = 1;
            this.SportsEvent.Text = "体育活动";
            this.SportsEvent.UseVisualStyleBackColor = false;
            this.SportsEvent.Click += new System.EventHandler(this.SportsEvent_Click);
            // 
            // PublicNotice
            // 
            this.PublicNotice.BackColor = System.Drawing.Color.Transparent;
            this.PublicNotice.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PublicNotice.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PublicNotice.Location = new System.Drawing.Point(276, 14);
            this.PublicNotice.Margin = new System.Windows.Forms.Padding(4);
            this.PublicNotice.Name = "PublicNotice";
            this.PublicNotice.Size = new System.Drawing.Size(110, 43);
            this.PublicNotice.TabIndex = 2;
            this.PublicNotice.Text = "添加公告";
            this.PublicNotice.UseVisualStyleBackColor = false;
            this.PublicNotice.Click += new System.EventHandler(this.PublicNotice_Click);
            // 
            // ListNotices
            // 
            this.ListNotices.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ad_id,
            this.ad_name,
            this.ad_content,
            this.ad_data_time});
            this.ListNotices.Location = new System.Drawing.Point(33, 121);
            this.ListNotices.Margin = new System.Windows.Forms.Padding(4);
            this.ListNotices.Name = "ListNotices";
            this.ListNotices.Size = new System.Drawing.Size(862, 410);
            this.ListNotices.TabIndex = 3;
            this.ListNotices.UseCompatibleStateImageBehavior = false;
            this.ListNotices.View = System.Windows.Forms.View.Details;
            this.ListNotices.SelectedIndexChanged += new System.EventHandler(this.ListNotices_SelectedIndexChanged);
            // 
            // ad_id
            // 
            this.ad_id.Text = "序号";
            this.ad_id.Width = 100;
            // 
            // ad_name
            // 
            this.ad_name.Text = "公告名称";
            this.ad_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ad_name.Width = 170;
            // 
            // ad_content
            // 
            this.ad_content.Text = "公告内容";
            this.ad_content.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ad_content.Width = 335;
            // 
            // ad_data_time
            // 
            this.ad_data_time.Text = "发布时间";
            this.ad_data_time.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ad_data_time.Width = 250;
            // 
            // FirstPage
            // 
            this.FirstPage.BackColor = System.Drawing.Color.Transparent;
            this.FirstPage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FirstPage.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FirstPage.Location = new System.Drawing.Point(39, 13);
            this.FirstPage.Margin = new System.Windows.Forms.Padding(4);
            this.FirstPage.Name = "FirstPage";
            this.FirstPage.Size = new System.Drawing.Size(90, 40);
            this.FirstPage.TabIndex = 4;
            this.FirstPage.Text = "首页";
            this.FirstPage.UseVisualStyleBackColor = false;
            this.FirstPage.Click += new System.EventHandler(this.FirstPage_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(186, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "公告ID：";
            // 
            // Id
            // 
            this.Id.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Id.Location = new System.Drawing.Point(330, 74);
            this.Id.Name = "Id";
            this.Id.Size = new System.Drawing.Size(178, 34);
            this.Id.TabIndex = 7;
            // 
            // search
            // 
            this.search.BackColor = System.Drawing.Color.Transparent;
            this.search.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.search.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.search.Location = new System.Drawing.Point(558, 71);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(105, 35);
            this.search.TabIndex = 8;
            this.search.Text = "搜索";
            this.search.UseVisualStyleBackColor = false;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportSystem.Properties.Resources.EB4FA52FEF11A44ED8D516B1C60A7768;
            this.pictureBox1.Location = new System.Drawing.Point(-4, -4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(952, 595);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 553);
            this.Controls.Add(this.search);
            this.Controls.Add(this.Id);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.FirstPage);
            this.Controls.Add(this.ListNotices);
            this.Controls.Add(this.PublicNotice);
            this.Controls.Add(this.SportsEvent);
            this.Controls.Add(this.UserCenter);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormTable";
            this.Text = "体育活动管理系统";
            this.Load += new System.EventHandler(this.FormTable_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button UserCenter;
        private System.Windows.Forms.Button SportsEvent;
        private System.Windows.Forms.Button PublicNotice;
        private System.Windows.Forms.ListView ListNotices;
        private System.Windows.Forms.ColumnHeader ad_id;
        private System.Windows.Forms.ColumnHeader ad_name;
        private System.Windows.Forms.ColumnHeader ad_content;
        private System.Windows.Forms.ColumnHeader ad_data_time;
        private System.Windows.Forms.Button FirstPage;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Id;
        private System.Windows.Forms.Button search;
    }
}