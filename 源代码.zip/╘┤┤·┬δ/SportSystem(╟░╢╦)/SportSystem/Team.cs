﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class Team
    {
        public string team_name;
        public List<int> user_id;

        public Team(string name, List<int> members)
        {
            team_name = name;
            user_id = members;
        }
    }
}
