﻿namespace SportSystem
{
    partial class FormLogin
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.labName = new System.Windows.Forms.Label();
            this.labPwd = new System.Windows.Forms.Label();
            this.inputUser_id = new System.Windows.Forms.TextBox();
            this.inputPwd = new System.Windows.Forms.TextBox();
            this.checkPwd = new System.Windows.Forms.CheckBox();
            this.Login = new System.Windows.Forms.Button();
            this.Reg = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labName
            // 
            this.labName.AutoSize = true;
            this.labName.BackColor = System.Drawing.Color.Transparent;
            this.labName.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labName.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labName.Location = new System.Drawing.Point(276, 130);
            this.labName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labName.Name = "labName";
            this.labName.Size = new System.Drawing.Size(82, 24);
            this.labName.TabIndex = 1;
            this.labName.Text = "学号：";
            this.labName.Click += new System.EventHandler(this.labName_Click);
            // 
            // labPwd
            // 
            this.labPwd.AutoSize = true;
            this.labPwd.BackColor = System.Drawing.Color.Transparent;
            this.labPwd.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labPwd.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labPwd.Location = new System.Drawing.Point(276, 234);
            this.labPwd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labPwd.Name = "labPwd";
            this.labPwd.Size = new System.Drawing.Size(82, 24);
            this.labPwd.TabIndex = 3;
            this.labPwd.Text = "密码：";
            // 
            // inputUser_id
            // 
            this.inputUser_id.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.inputUser_id.Location = new System.Drawing.Point(397, 127);
            this.inputUser_id.Margin = new System.Windows.Forms.Padding(4);
            this.inputUser_id.Name = "inputUser_id";
            this.inputUser_id.Size = new System.Drawing.Size(270, 34);
            this.inputUser_id.TabIndex = 4;
            // 
            // inputPwd
            // 
            this.inputPwd.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.inputPwd.Location = new System.Drawing.Point(397, 231);
            this.inputPwd.Margin = new System.Windows.Forms.Padding(4);
            this.inputPwd.Name = "inputPwd";
            this.inputPwd.PasswordChar = '*';
            this.inputPwd.Size = new System.Drawing.Size(270, 34);
            this.inputPwd.TabIndex = 5;
            // 
            // checkPwd
            // 
            this.checkPwd.AutoSize = true;
            this.checkPwd.BackColor = System.Drawing.Color.Transparent;
            this.checkPwd.FlatAppearance.BorderSize = 0;
            this.checkPwd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkPwd.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.checkPwd.Location = new System.Drawing.Point(543, 302);
            this.checkPwd.Margin = new System.Windows.Forms.Padding(4);
            this.checkPwd.Name = "checkPwd";
            this.checkPwd.Size = new System.Drawing.Size(124, 28);
            this.checkPwd.TabIndex = 10;
            this.checkPwd.Text = "显示密码";
            this.checkPwd.UseVisualStyleBackColor = false;
            this.checkPwd.CheckedChanged += new System.EventHandler(this.checkPwd_CheckedChanged);
            // 
            // Login
            // 
            this.Login.BackColor = System.Drawing.Color.Transparent;
            this.Login.FlatAppearance.BorderSize = 0;
            this.Login.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Login.Location = new System.Drawing.Point(301, 391);
            this.Login.Margin = new System.Windows.Forms.Padding(4);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(96, 44);
            this.Login.TabIndex = 11;
            this.Login.Text = "登录";
            this.Login.UseVisualStyleBackColor = false;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // Reg
            // 
            this.Reg.BackColor = System.Drawing.Color.Transparent;
            this.Reg.FlatAppearance.BorderSize = 0;
            this.Reg.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Reg.Location = new System.Drawing.Point(529, 389);
            this.Reg.Margin = new System.Windows.Forms.Padding(4);
            this.Reg.Name = "Reg";
            this.Reg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Reg.Size = new System.Drawing.Size(95, 46);
            this.Reg.TabIndex = 12;
            this.Reg.Text = "注册";
            this.Reg.UseVisualStyleBackColor = false;
            this.Reg.Click += new System.EventHandler(this.Reg_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportSystem.Properties.Resources.EB4FA52FEF11A44ED8D516B1C60A7768;
            this.pictureBox1.Location = new System.Drawing.Point(-12, -41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(960, 600);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 553);
            this.Controls.Add(this.Reg);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.checkPwd);
            this.Controls.Add(this.inputPwd);
            this.Controls.Add(this.inputUser_id);
            this.Controls.Add(this.labPwd);
            this.Controls.Add(this.labName);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormLogin";
            this.Text = "欢迎登录";
            this.Load += new System.EventHandler(this.FormLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labName;
        private System.Windows.Forms.Label labPwd;
        private System.Windows.Forms.TextBox inputUser_id;
        private System.Windows.Forms.TextBox inputPwd;
        private System.Windows.Forms.CheckBox checkPwd;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Button Reg;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

