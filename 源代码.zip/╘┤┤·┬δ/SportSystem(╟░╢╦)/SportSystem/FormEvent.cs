﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormEvent : Form
    {
        public FormEvent()
        {
            InitializeComponent();
        }

        private void EventInfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormEventInfo().ShowDialog(this);
        }

        private void CreateEvent_Click(object sender, EventArgs e)
        {
            if (Common.admin == 1)
            {
                this.Hide();
                new FormCreateEvent().ShowDialog(this);
            }
            else
            {
                MessageBox.Show("对不起，仅有管理员才有此权限！");
            }
        }

        private void DeleteEvent_Click(object sender, EventArgs e)
        {
            if (Common.admin == 1)
            {
                this.Hide();
                new FormDeleteEvent().ShowDialog(this);
            }
            else
            {
                MessageBox.Show("对不起，仅有管理员才有此权限！");
            }
        }

        private void FormEvent_Load(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(0, 0);
            EventInfo.Parent = pictureBox1;
            Back.Parent = pictureBox1;
            CreateEvent.Parent = pictureBox1;
            DeleteEvent.Parent = pictureBox1;
            EventState.Parent = pictureBox1;
        }

        private void EventState_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormEventState().ShowDialog(this);
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
