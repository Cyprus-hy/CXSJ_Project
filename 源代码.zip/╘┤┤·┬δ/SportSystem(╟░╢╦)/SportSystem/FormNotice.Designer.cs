﻿namespace SportSystem
{
    partial class FormNotice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SearchAd = new System.Windows.Forms.Button();
            this.PostAd = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SearchAd
            // 
            this.SearchAd.BackColor = System.Drawing.Color.Transparent;
            this.SearchAd.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SearchAd.Location = new System.Drawing.Point(368, 155);
            this.SearchAd.Margin = new System.Windows.Forms.Padding(4);
            this.SearchAd.Name = "SearchAd";
            this.SearchAd.Size = new System.Drawing.Size(169, 45);
            this.SearchAd.TabIndex = 3;
            this.SearchAd.Text = "查看公告";
            this.SearchAd.UseVisualStyleBackColor = false;
            this.SearchAd.Click += new System.EventHandler(this.SearchAd_Click);
            // 
            // PostAd
            // 
            this.PostAd.BackColor = System.Drawing.Color.Transparent;
            this.PostAd.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.PostAd.Location = new System.Drawing.Point(368, 313);
            this.PostAd.Margin = new System.Windows.Forms.Padding(4);
            this.PostAd.Name = "PostAd";
            this.PostAd.Size = new System.Drawing.Size(169, 47);
            this.PostAd.TabIndex = 4;
            this.PostAd.Text = "添加公告";
            this.PostAd.UseVisualStyleBackColor = false;
            this.PostAd.Click += new System.EventHandler(this.PostAd_Click);
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.Transparent;
            this.Back.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Back.Location = new System.Drawing.Point(12, 12);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(97, 33);
            this.Back.TabIndex = 5;
            this.Back.Text = "返回";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportSystem.Properties.Resources.EB4FA52FEF11A44ED8D516B1C60A7768;
            this.pictureBox1.Location = new System.Drawing.Point(-3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(946, 563);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormNotice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 553);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.PostAd);
            this.Controls.Add(this.SearchAd);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormNotice";
            this.Text = "通知公告";
            this.Load += new System.EventHandler(this.FormNotice_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button SearchAd;
        private System.Windows.Forms.Button PostAd;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}