﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private string HttpPost(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = Encoding.UTF8.GetByteCount(postDataStr);
            Stream myRequestStream = request.GetRequestStream();
            StreamWriter myStreamWriter = new StreamWriter(myRequestStream, Encoding.GetEncoding("gb2312"));
            myStreamWriter.Write(postDataStr);
            myStreamWriter.Close();

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();

            return retString;
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            inputUser_id.Text = "";
            inputPwd.Text = "";
            inputUser_id.Focus();//自动得到焦点
            pictureBox1.Location = new Point(0, 0);
            labName.Parent = pictureBox1;
            labPwd.Parent = pictureBox1;
            checkPwd.Parent = pictureBox1;
        }

        private void checkPwd_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPwd.Checked == true)
            {
                inputPwd.PasswordChar = new char();
            }
            else
            {
                inputPwd.PasswordChar = '*';
            }
        }

        private void Login_Click(object sender, EventArgs e)
        {
            if (ToolUtil.isEmpty(inputUser_id.Text) || ToolUtil.isEmpty(inputPwd.Text))
            {
                MessageBox.Show("请输入学号和密码！");
                return;
            }

            int userID = Convert.ToInt32(inputUser_id.Text);
            string password = Convert.ToString(inputPwd.Text);

            LoginUser newobj = new LoginUser(userID, password);
            string PostURL = "http://localhost/cxsj_final_project-master/Home/Log/postLogin";
            string jsonContent = JsonConvert.SerializeObject(newobj);
            string Param = "Content=" + jsonContent;
            string result = HttpPost(PostURL, Param);
            IsLogin resultobj = JsonConvert.DeserializeObject<IsLogin>(result);

            if (!resultobj.is_login)
            {
                MessageBox.Show("学号或密码错误！");
            }
            else
            {
                if (resultobj.is_admin)
                {
                    Common.admin = 1;
                    MessageBox.Show("管理者登录成功！");
                }
                    
                else
                    MessageBox.Show("学生登录成功！");

                /*FrmTable newForm = new FrmTable();
                this.Hide();
                newForm.ShowDialog();
                Application.ExitThread();*/
                Common.Login_ID = userID;

                this.Hide();
                new FormTable().Show();
            }
        }

        private void Reg_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormReg().ShowDialog(this);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void labName_Click(object sender, EventArgs e)
        {

        }
    }
}
