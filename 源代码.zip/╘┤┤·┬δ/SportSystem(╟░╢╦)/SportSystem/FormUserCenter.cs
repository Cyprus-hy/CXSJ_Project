﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormUserCenter : Form
    {
        public FormUserCenter()
        {
            InitializeComponent();
        }

        private void FormUserCenter_Load(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(0, 0);
            UserInfo.Parent = pictureBox1;
            JoinedTeam.Parent = pictureBox1;
            CreateTeam.Parent = pictureBox1;
            BacktoTable.Parent = pictureBox1;
            LogOut.Parent = pictureBox1;
        }

        private void UserInfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormUserInfo().ShowDialog(this);
        }

        private void CreateTeam_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormCreateTeam().ShowDialog(this);
        }

        private void JoinedTeam_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormJoinedTeam().ShowDialog(this);
        }

        private void BacktoTable_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void LogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FormLogin().ShowDialog(this);
        }
    }
}
