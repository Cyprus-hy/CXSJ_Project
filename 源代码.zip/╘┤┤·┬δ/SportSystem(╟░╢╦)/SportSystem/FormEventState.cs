﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormEventState : Form
    {
        public FormEventState()
        {
            InitializeComponent();
        }

        public string HttpGet(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url + (postDataStr == "" ? "" : "?") + postDataStr);
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            return retString;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void ListReg_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FormEventState_Load(object sender, EventArgs e)
        {
            ListReg.Items.Clear();//清除表格

            string URL = "http://localhost/cxsj_final_project-master/Home/Event/getState";
            string result = HttpGet(URL, "");
            List<Reg> resultobj = JsonConvert.DeserializeObject<List<Reg>>(result);
            int count = resultobj.Count();

            for (int i = 0; i < count; i++)
            {
                ListViewItem lv = new ListViewItem();
                lv.Text = Convert.ToString(resultobj[i].event_id);//第一列数据
                lv.SubItems.Add(Convert.ToString(resultobj[i].team_id));
                lv.SubItems.Add(Convert.ToString(resultobj[i].user_id));
                lv.SubItems.Add(resultobj[i].user_name);
                ListReg.Items.Add(lv);
            }
        }

        private void Back_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void Back_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
