﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class PostAd
    {
        public string ad_name;
        public string ad_content;

        public PostAd(string AdName, string AdContent)
        {
            ad_name = AdName;
            ad_content = AdContent;
        }
    }
}
