﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class PostEvent
    {
        public string event_name;
        public int max_team_member;
        public int min_team_member;
        public int team_limit;
        public int year;

        public PostEvent(string name, int max_mem, int min_mem, int limit, int y)
        {
            event_name = name;
            max_team_member = max_mem;
            min_team_member = min_mem;
            team_limit = limit;
            year = y;
        }
    }
}
