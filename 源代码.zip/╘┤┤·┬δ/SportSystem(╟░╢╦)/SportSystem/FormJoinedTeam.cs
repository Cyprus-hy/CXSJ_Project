﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormJoinedTeam : Form
    {
        public FormJoinedTeam()
        {
            InitializeComponent();
        }

        public string HttpGet(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url + (postDataStr == "" ? "" : "?") + postDataStr);
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            return retString;
        }

        private void FormJoinedTeam_Load(object sender, EventArgs e)
        {
            ListJoinedTeam.Items.Clear();//清除表格
            pictureBox1.Location = new Point(0, 0);
            Back.Parent = pictureBox1;

            string URL = "http://localhost/cxsj_final_project-master/Home/User/getRegInfoByUserID/"+Convert.ToString(Common.Login_ID);
            string result = HttpGet(URL, "");
            List<JoinedTeam> resultobj = JsonConvert.DeserializeObject<List<JoinedTeam>>(result);
            int count = resultobj.Count();

            for (int i = 0; i < count; i++)
            {
                ListViewItem lv = new ListViewItem();
                lv.Text = Convert.ToString(resultobj[i].team_id);//第一列数据
                lv.SubItems.Add(resultobj[i].team_name);
                lv.SubItems.Add(Convert.ToString(resultobj[i].event_id));
                lv.SubItems.Add(resultobj[i].event_name);
                lv.SubItems.Add(resultobj[i].reg_time);
                ListJoinedTeam.Items.Add(lv);
            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
