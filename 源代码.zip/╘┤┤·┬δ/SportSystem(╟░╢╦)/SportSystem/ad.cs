﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class ad
    {
        public int ad_id;
        public string ad_name;
        public string ad_content;
        public string ad_data_time;

        public ad(int AdID, string AdName, string AdContent, string AdTime)
        {
            ad_id = AdID;
            ad_name = AdName;
            ad_content = AdContent;
            ad_data_time = AdTime;
        }
    }
}
