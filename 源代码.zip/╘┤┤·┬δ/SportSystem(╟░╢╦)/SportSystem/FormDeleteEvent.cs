﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormDeleteEvent : Form
    {
        public FormDeleteEvent()
        {
            InitializeComponent();
        }

        public string HttpGet(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url + (postDataStr == "" ? "" : "?") + postDataStr);
            request.Method = "GET";
            request.ContentType = "text/html;charset=UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();
            return retString;
        }

        private void FormDeleteEvent_Load(object sender, EventArgs e)
        {
            ID.Text = "";

            pictureBox1.Location = new Point(0, 0);
            label1.Parent = pictureBox1;
            Back.Parent = pictureBox1;
            Delete.Parent = pictureBox1;
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            string URL = "http://localhost/cxsj_final_project-master/Home/Event/delEventByID/" + ID.Text;
            string content = HttpGet(URL, "");
            MessageBox.Show("删除成功！");
            ID.Text = "";
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
