﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace SportSystem
{
    public partial class FormPostAd : Form
    {
        public FormPostAd()
        {
            InitializeComponent();
        }

        private string HttpPost(string Url, string postDataStr)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = Encoding.UTF8.GetByteCount(postDataStr);
            Stream myRequestStream = request.GetRequestStream();
            StreamWriter myStreamWriter = new StreamWriter(myRequestStream, Encoding.GetEncoding("gb2312"));
            myStreamWriter.Write(postDataStr);
            myStreamWriter.Close();

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            Stream myResponseStream = response.GetResponseStream();
            StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
            string retString = myStreamReader.ReadToEnd();
            myStreamReader.Close();
            myResponseStream.Close();

            return retString;
        }

        private void Submit_Click(object sender, EventArgs e)
        {
            PostAd newobj = new PostAd(Title.Text, Content.Text);
            string PostURL = "http://localhost/cxsj_final_project-master/Home/Billboard/postNewBillboard";
            string jsonContent = JsonConvert.SerializeObject(newobj);
            string Param = "Content=" + jsonContent;
            string result = HttpPost(PostURL, Param);

            MessageBox.Show("添加成功！");

            Title.Text = "";
            Content.Text = "";
        }

        private void FormPostAd_Load(object sender, EventArgs e)
        {
            Title.Text = "";
            Content.Text = "";
            Title.Focus();

            pictureBox1.Location = new Point(0, 0);
            label1.Parent = pictureBox1;
            label2.Parent = pictureBox1;
            Back.Parent = pictureBox1;
            Submit.Parent = pictureBox1;
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Owner.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
