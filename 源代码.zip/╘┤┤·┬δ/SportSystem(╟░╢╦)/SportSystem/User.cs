﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportSystem
{
    class User
    {
        public int user_id;
        public int department_id;
        public string phone;
        public int gender;
        public string email;
        public string name;
        public string password;

        public User(int UserID, string UserName, string UserPhone, int UserGender,
            string UserEmail, int DepID, string Password)
        {
            user_id = UserID;
            name = UserName;
            phone = UserPhone;
            gender = UserGender;
            email = UserEmail;
            department_id = DepID;
            password = Password;
        }
    }
}
