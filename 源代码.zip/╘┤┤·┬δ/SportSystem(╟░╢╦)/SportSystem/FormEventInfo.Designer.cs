﻿namespace SportSystem
{
    partial class FormEventInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Back = new System.Windows.Forms.Button();
            this.EventID = new System.Windows.Forms.TextBox();
            this.Search = new System.Windows.Forms.Button();
            this.ListEvent = new System.Windows.Forms.ListView();
            this.event_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.event_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.max_team_member = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.min_team_member = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.team_limit = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.year = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Join = new System.Windows.Forms.Button();
            this.TeamID = new System.Windows.Forms.Label();
            this.id_team = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(183, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "活动ID：";
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.Transparent;
            this.Back.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Back.Location = new System.Drawing.Point(12, 12);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(90, 35);
            this.Back.TabIndex = 1;
            this.Back.Text = "返回";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // EventID
            // 
            this.EventID.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EventID.Location = new System.Drawing.Point(295, 66);
            this.EventID.Name = "EventID";
            this.EventID.Size = new System.Drawing.Size(223, 34);
            this.EventID.TabIndex = 2;
            // 
            // Search
            // 
            this.Search.BackColor = System.Drawing.Color.Transparent;
            this.Search.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Search.Location = new System.Drawing.Point(576, 66);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(93, 36);
            this.Search.TabIndex = 3;
            this.Search.Text = "搜索";
            this.Search.UseVisualStyleBackColor = false;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // ListEvent
            // 
            this.ListEvent.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.event_id,
            this.event_name,
            this.max_team_member,
            this.min_team_member,
            this.team_limit,
            this.year});
            this.ListEvent.Location = new System.Drawing.Point(12, 141);
            this.ListEvent.Margin = new System.Windows.Forms.Padding(4);
            this.ListEvent.Name = "ListEvent";
            this.ListEvent.Size = new System.Drawing.Size(924, 246);
            this.ListEvent.TabIndex = 6;
            this.ListEvent.UseCompatibleStateImageBehavior = false;
            this.ListEvent.View = System.Windows.Forms.View.Details;
            // 
            // event_id
            // 
            this.event_id.Text = "序号";
            this.event_id.Width = 80;
            // 
            // event_name
            // 
            this.event_name.Text = "活动名称";
            this.event_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.event_name.Width = 200;
            // 
            // max_team_member
            // 
            this.max_team_member.Text = "最大队员数";
            this.max_team_member.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.max_team_member.Width = 150;
            // 
            // min_team_member
            // 
            this.min_team_member.Text = "最小队员数";
            this.min_team_member.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.min_team_member.Width = 150;
            // 
            // team_limit
            // 
            this.team_limit.Text = "队伍数量限制";
            this.team_limit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.team_limit.Width = 170;
            // 
            // year
            // 
            this.year.Text = "比赛年份";
            this.year.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.year.Width = 170;
            // 
            // Join
            // 
            this.Join.BackColor = System.Drawing.Color.Transparent;
            this.Join.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Join.Location = new System.Drawing.Point(576, 459);
            this.Join.Name = "Join";
            this.Join.Size = new System.Drawing.Size(93, 34);
            this.Join.TabIndex = 7;
            this.Join.Text = "报名";
            this.Join.UseVisualStyleBackColor = false;
            this.Join.Click += new System.EventHandler(this.Join_Click);
            // 
            // TeamID
            // 
            this.TeamID.AutoSize = true;
            this.TeamID.BackColor = System.Drawing.Color.Transparent;
            this.TeamID.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TeamID.Location = new System.Drawing.Point(183, 462);
            this.TeamID.Name = "TeamID";
            this.TeamID.Size = new System.Drawing.Size(106, 24);
            this.TeamID.TabIndex = 9;
            this.TeamID.Text = "队伍ID：";
            // 
            // id_team
            // 
            this.id_team.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.id_team.Location = new System.Drawing.Point(295, 459);
            this.id_team.Name = "id_team";
            this.id_team.Size = new System.Drawing.Size(223, 34);
            this.id_team.TabIndex = 10;
            this.id_team.TextChanged += new System.EventHandler(this.id_team_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportSystem.Properties.Resources.EB4FA52FEF11A44ED8D516B1C60A7768;
            this.pictureBox1.Location = new System.Drawing.Point(-4, -5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(951, 565);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormEventInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 553);
            this.Controls.Add(this.id_team);
            this.Controls.Add(this.TeamID);
            this.Controls.Add(this.Join);
            this.Controls.Add(this.ListEvent);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.EventID);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormEventInfo";
            this.Text = "活动信息";
            this.Load += new System.EventHandler(this.FormEventInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.TextBox EventID;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.ListView ListEvent;
        private System.Windows.Forms.ColumnHeader event_id;
        private System.Windows.Forms.ColumnHeader event_name;
        private System.Windows.Forms.ColumnHeader max_team_member;
        private System.Windows.Forms.ColumnHeader min_team_member;
        private System.Windows.Forms.ColumnHeader team_limit;
        private System.Windows.Forms.ColumnHeader year;
        private System.Windows.Forms.Button Join;
        private System.Windows.Forms.Label TeamID;
        private System.Windows.Forms.TextBox id_team;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}