CREATE TABLE sport_system.billboard
(
    ad_id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    ad_name varchar(100),
    ad_content varchar(100),
    ad_data_time timestamp DEFAULT CURRENT_TIMESTAMP,
    is_delete int(11) DEFAULT '0'
);
INSERT INTO sport_system.billboard (ad_id, ad_name, ad_content, ad_data_time, is_delete) VALUES (1, 'football', 'football game start', '2018-10-23 05:06:13', 0);
INSERT INTO sport_system.billboard (ad_id, ad_name, ad_content, ad_data_time, is_delete) VALUES (2, 'basketball', 'basketball game start', '2018-10-23 05:23:06', 0);
INSERT INTO sport_system.billboard (ad_id, ad_name, ad_content, ad_data_time, is_delete) VALUES (3, 'aaa', 'bbb', '2018-10-29 19:44:52', 0);
INSERT INTO sport_system.billboard (ad_id, ad_name, ad_content, ad_data_time, is_delete) VALUES (4, 'ccc', 'ddd', '2018-10-29 19:46:21', 0);
INSERT INTO sport_system.billboard (ad_id, ad_name, ad_content, ad_data_time, is_delete) VALUES (5, 'asdddd', 'dsss', '2018-11-04 17:07:22', 0);
INSERT INTO sport_system.billboard (ad_id, ad_name, ad_content, ad_data_time, is_delete) VALUES (6, 'run', 'run ten kilometers', '2018-11-04 19:28:10', 0);
CREATE TABLE sport_system.college_name
(
    department_id int(11) PRIMARY KEY NOT NULL,
    department_name varchar(50)
);
INSERT INTO sport_system.college_name (department_id, department_name) VALUES (1, 'computer science ');
INSERT INTO sport_system.college_name (department_id, department_name) VALUES (2, 'sortware college');
CREATE TABLE sport_system.department
(
    department_id int(11) NOT NULL,
    grade int(11) NOT NULL,
    class int(11) NOT NULL,
    is_delete int(11) DEFAULT '0',
    CONSTRAINT `PRIMARY` PRIMARY KEY (department_id, class, grade)
);
INSERT INTO sport_system.department (department_id, grade, class, is_delete) VALUES (1, 1, 1, 0);
INSERT INTO sport_system.department (department_id, grade, class, is_delete) VALUES (2, 1, 1, 0);
CREATE TABLE sport_system.event
(
    event_id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    event_name varchar(30),
    max_team_member int(11),
    min_team_member int(11),
    team_limit int(11),
    year int(11),
    is_delete int(11) DEFAULT '0'
);
INSERT INTO sport_system.event (event_id, event_name, max_team_member, min_team_member, team_limit, year, is_delete) VALUES (10, '泡泡足球', 11, 11, 100, 2018, 0);
INSERT INTO sport_system.event (event_id, event_name, max_team_member, min_team_member, team_limit, year, is_delete) VALUES (11, '泡泡篮球', 5, 0, 100, 2018, 0);
INSERT INTO sport_system.event (event_id, event_name, max_team_member, min_team_member, team_limit, year, is_delete) VALUES (12, '大', 8, 5, 3, 2018, 1);
INSERT INTO sport_system.event (event_id, event_name, max_team_member, min_team_member, team_limit, year, is_delete) VALUES (13, 'add', 10, 8, 5, 2018, 0);
INSERT INTO sport_system.event (event_id, event_name, max_team_member, min_team_member, team_limit, year, is_delete) VALUES (14, 'run', 3, 1, 20, 2018, 1);
INSERT INTO sport_system.event (event_id, event_name, max_team_member, min_team_member, team_limit, year, is_delete) VALUES (15, 'run', 5, 3, 20, 2018, 1);
CREATE TABLE sport_system.`match`
(
    match_id int(11) PRIMARY KEY NOT NULL,
    `order` int(11),
    score int(11),
    is_finished int(11),
    vs_time int(11),
    event_id int(11),
    team_id int(11),
    is_delete int(11) DEFAULT '0'
);
CREATE TABLE sport_system.passwd
(
    user_id int(11) PRIMARY KEY NOT NULL,
    password varchar(100),
    is_delete int(11) DEFAULT '0'
);
CREATE UNIQUE INDEX passwd_user_id_uindex ON sport_system.passwd (user_id);
INSERT INTO sport_system.passwd (user_id, password, is_delete) VALUES (20165083, '1998', 0);
CREATE TABLE sport_system.registration
(
    reg_id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    team_id int(11),
    event_id int(11),
    create_time timestamp DEFAULT CURRENT_TIMESTAMP,
    is_delete int(11) DEFAULT '0'
);
INSERT INTO sport_system.registration (reg_id, team_id, event_id, create_time, is_delete) VALUES (1, 1, 10, '2018-10-24 13:48:52', 0);
INSERT INTO sport_system.registration (reg_id, team_id, event_id, create_time, is_delete) VALUES (2, 3, 10, '2018-10-29 10:21:34', 0);
INSERT INTO sport_system.registration (reg_id, team_id, event_id, create_time, is_delete) VALUES (3, 2, 11, '2018-10-24 21:08:23', 0);
INSERT INTO sport_system.registration (reg_id, team_id, event_id, create_time, is_delete) VALUES (4, 4, 11, '2018-10-24 21:48:03', 0);
INSERT INTO sport_system.registration (reg_id, team_id, event_id, create_time, is_delete) VALUES (8, 11, 13, '2018-10-29 20:25:34', 0);
INSERT INTO sport_system.registration (reg_id, team_id, event_id, create_time, is_delete) VALUES (6, 13, 9, '2018-10-29 20:15:45', 0);
INSERT INTO sport_system.registration (reg_id, team_id, event_id, create_time, is_delete) VALUES (7, 10, 13, '2018-10-29 20:19:07', 0);
INSERT INTO sport_system.registration (reg_id, team_id, event_id, create_time, is_delete) VALUES (9, 8, 10, '2018-11-04 16:51:17', 0);
INSERT INTO sport_system.registration (reg_id, team_id, event_id, create_time, is_delete) VALUES (10, 13, 11, '2018-11-04 19:41:29', 0);
CREATE TABLE sport_system.team
(
    team_id int(11) NOT NULL,
    user_id int(11) NOT NULL,
    is_delete int(11) DEFAULT '0',
    CONSTRAINT `PRIMARY` PRIMARY KEY (team_id, user_id)
);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (1, 1, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (1, 4, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (2, 3, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (2, 5, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (3, 3, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (3, 5, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (4, 0, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (4, 1, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (6, 1, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (8, 1, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (8, 2, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (9, 1, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (10, 1, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (11, 1, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (12, 22, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (12, 77, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (13, 1, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (13, 2, 0);
INSERT INTO sport_system.team (team_id, user_id, is_delete) VALUES (13, 3, 0);
CREATE TABLE sport_system.team_name
(
    team_id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    team_name varchar(50),
    is_delete int(11) DEFAULT '0'
);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (1, 'team1', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (2, 'team2', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (3, 'team3', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (4, 'team4', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (5, null, 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (6, 'aaa', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (7, 'ddd', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (8, 'ed', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (9, 'ddds', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (10, 'ddsx', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (11, 'asdzxc', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (12, 'mm', 0);
INSERT INTO sport_system.team_name (team_id, team_name, is_delete) VALUES (13, 'hello world', 0);
CREATE TABLE sport_system.user
(
    user_id int(11) PRIMARY KEY NOT NULL,
    department_id int(11),
    phone varchar(20),
    gender int(11),
    email varchar(50),
    name varchar(20),
    is_delete int(11) DEFAULT '0',
    is_admin int(11) DEFAULT '0',
    password varchar(100)
);
INSERT INTO sport_system.user (user_id, department_id, phone, gender, email, name, is_delete, is_admin, password) VALUES (1, 1, '13072339523', 1, 'a215900031@gmail', 'zsy', 0, 0, '123');
INSERT INTO sport_system.user (user_id, department_id, phone, gender, email, name, is_delete, is_admin, password) VALUES (2, 2, '996996', null, 'djytyang@gmail.com', 'hy', 0, 1, '456');
INSERT INTO sport_system.user (user_id, department_id, phone, gender, email, name, is_delete, is_admin, password) VALUES (3, 1, '44', null, '215900031@qq.com', 'jzl', 0, 0, '11');
INSERT INTO sport_system.user (user_id, department_id, phone, gender, email, name, is_delete, is_admin, password) VALUES (4, 1, '334', null, '123@qq.com', 'zhm', 0, 0, '22');
INSERT INTO sport_system.user (user_id, department_id, phone, gender, email, name, is_delete, is_admin, password) VALUES (5, 2, '231', null, '20165083@cqu.edu.cn', 'ljj', 0, 0, '33');
INSERT INTO sport_system.user (user_id, department_id, phone, gender, email, name, is_delete, is_admin, password) VALUES (20164450, 1, '17709091833', 1, '1550991833@qq.com', 'David', 0, 0, '123456');