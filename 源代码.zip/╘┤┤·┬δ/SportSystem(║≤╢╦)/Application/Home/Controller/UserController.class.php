<?php
/**
 * Created by PhpStorm.
 * User: zhu
 * Date: 2018/10/24
 * Time: 11:38
 */

namespace Home\Controller;

use Home\Model\EventModel;
use Home\Model\RegistrationModel;
use Home\Model\TeamModel;
use Think\Controller\RestController;
use Home\Model\UserModel;
use Think\Model;

class UserController extends RestController {
    public function postNewUser() {
        $obj = json_decode($_POST["Content"]);
        $user_id = $obj->user_id;
        $name = $obj->name;
        $phone = $obj->phone;
        $gender = $obj->gender;
        $email = $obj->email;
        $department_id = $obj->department_id;
        $password = $obj->password;
        $this->_addNewUser($user_id, $name, $phone, $gender, $email, $password, $department_id);
    }

    public function getInfoByUserID($id) {
        $data = $this->_getInfoByUserID($id);
        $this->response($data,'json');
    }

    public function getInfoByDepartID($id) {
        $data = $this->_getInfoByDepartID($id);
        $this->response($data,'json');
    }

    public function getRegInfoByUserID($id){
        $sql = new Model();
        $res=$sql->query("SELECT t.team_id as team_id,tn.team_name as team_name,r.event_id as event_id,e.event_name as event_name,r.create_time as reg_time FROM team t,team_name tn,registration r, event e WHERE t.user_id=$id and t.team_id=tn.team_id and r.team_id=t.team_id and e.event_id=r.event_id");
        $this->response($res, "json");
    }

    private function _addNewUser($user_id, $name, $phone, $gender, $email, $password, $department_id) {
        $data = array();
        $data['user_id'] = $user_id;
        $data['name'] = $name;
        $data['phone'] = $phone;
        $data['gender'] = $gender;
        $data['email'] = $email;
        $data['department_id'] = $department_id;
        $data['password'] = $password;
        $sql = new UserModel();
        $info = $sql->field('*')->where("user_id=$user_id")->select();
        if ($info[0] == null) {
            $sql->add($data);
            $this->response(array("is_exist" => false), 'json');
        } else {
            $this->response(array("is_exist" => true), 'json');
        }
    }

    private function _getInfoByUserID($id) {
        $info = array();
        $sql = new UserModel();
        $res = $sql->field('user_id,name,department_id,phone,gender,email,password')->where("user_id=$id")->select();
        return $res[0];
    }

    private function _getInfoByDepartID($id) {
        $info = array();
        $sql = new Model('college_name');
        $res = $sql->field('department_name')->where("department_id=$id")->select();
        foreach ($res as $key => $value) {
            $info[$key] = $value;
        }
        return $res[0]['department_name'];
    }
}