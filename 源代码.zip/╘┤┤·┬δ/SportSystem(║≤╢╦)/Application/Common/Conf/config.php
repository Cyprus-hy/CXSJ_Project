<?php
return array(
	//'配置项'=>'配置值'
    'DB_TYPE' => 'mysql', // 数据库类型
    'DB_HOST' => 'localhost', // 服务器地址 => 'thinkphp', // 数据库名
    'DB_NAME' => 'sport_system',
    'DB_USER' => 'root', // 用户名
    'DB_PWD' => '', // 密码
    'DB_PORT' => 3306, // 端口
    'DB_CHARSET' => 'utf8',
);